<?php
    include "calendario.php";
    include "conexao.php";

    $id = mysqli_real_escape_string($connect, $_GET['id']);
    $nome = mysqli_real_escape_string($connect, $_GET['nome']);
    $cod = mysqli_real_escape_string($connect, $_GET['cod']);
    $telefone = mysqli_real_escape_string($connect, $_GET['telefone']);
    $convenio = mysqli_real_escape_string($connect, $_GET['convenio']);
    $cidade = mysqli_real_escape_string($connect, $_GET['cidade']);
    $medico = mysqli_real_escape_string($connect, $_GET['medico']);
    $data_hora = mysqli_real_escape_string($connect, $_GET['data_consulta']);

    $result_eventos = "SELECT * FROM consulta";
    $resultado_eventos = mysqli_query($connect, $result_eventos);
?>

<!DOCTYPE HTML>
<html lang="pt-BR">
    <head>
        <meta charset = UTF-8>
        <title>Agenda</title>
        <link rel="stylesheet" type="text/css" href="./style.css"/>
        <link href="bootstrap.min.css" rel="stylesheet">
        <script type="text/javascript" src="jquery-1.9.1.js"></script>
        <script type="text/javascript" src="functions.js"></script>
        
        
        <script type="text/javascript">
            $(document).ready(function(e) {
                $('.btn_modal').click(function(e) {
                    e.preventDefault();
                   $('#modal').fadeIn(500);
                });
                $('.fechar').click(function(e) {
                    $('#modal').fadeOut(500);
                    e.preventDefault();
                });
            });
        </script>

        <input type="button" value="Cadastrar Consulta" class="btn_modal" />
        <div id="modal">
            <div class="modal-box">
                <div class="modal-header">
                    <buton type="button" class="fechar" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x</span></button>
                    <h4 class="modal-title tex-center" id="myModalLabel">Cadastrar Consulta</h4>
                </div>
                <div class="modal-body">
                    <form method="GET" action="conexao.php" enctype="multipart/form-data">
                        
                            <input name="nome" type="text" class="form-control" placeholder="Nome">

                            <input name="cod" type="text" class="form-control" placeholder="Código">

                            <input name="telefone" type="text" class="form-control" placeholder="Telefone">

                            <input name="convenio" type="text" class="form-control" placeholder="Convênio">

                            <input name="cidade" type="text" class="form-control" placeholder="Cidade">

                            <input name="medico" type="text" class="form-control" placeholder="Médico">

                            <input name="data_consulta" type="datetime-local" class="form-control" placeholder="Data e Hora">
                    
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Cadastrar</button>
                </div>
            </div>
            <div class="fechar">X</div>
        </div>

            Teste
        <input type="button" value="Visualizar Consulta" class="btn_modal" />
        <div id="modal">
            <div class="modal-box">
                <div class="modal-header">
                    <buton type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">$times;</span></button>
                    <h4 class="modal-title tex-center" id="myModalLabel">Visualizar Consulta</h4>
                </div>
                <div class="modal-body">
                        <div>
                           <?php 
                           
                           while($row_eventos = mysqli_fetch_assoc($resultado_eventos)){ ?>
                            <tr>
                                <?php echo 'Nome: ' .$row_eventos['nome'] ?> </br>
                                <td><?php echo 'Código: ' .$row_eventos['cod'] ?></br></td>
                                <td><?php echo 'Telefone: ' .$row_eventos['telefone'] ?></br></td>
                                <td><?php echo 'Convênio: ' .$row_eventos['convenio'] ?></br></td>
                                <td><?php echo 'Cidade: ' .$row_eventos['cidade'] ?></br></td>
                                <td><?php echo 'Indicação: ' .$row_eventos['medico'] ?></br></td>
                                <td><?php echo 'Data/Hora: ' .$row_eventos['data_consulta'] ?></br></td>
                            </tr>
                
                            <?php } ?>

                        </div>
                </div>
                <div class="modal-footer">
                </div>
            </div>
            <div class="fechar">X</div>
        </div>
    
    </head>

    <body>

    <div class="calendario">
        <?php
            //echo '<prev>';
            //Calendario(); 
        ?>
    </div>

    <?php

        while($row_eventos = mysqli_fetch_assoc($resultado_eventos)){ ?>
            <tr>
                <td><?php echo 'Nome: ' .$row_eventos['nome'] ?> </br></td>
                <td><?php echo 'Código: ' .$row_eventos['cod'] ?></br></td>
                <td><?php echo 'Telefone: ' .$row_eventos['telefone'] ?></br></td>
                <td><?php echo 'Convênio: ' .$row_eventos['convenio'] ?></br></td>
                <td><?php echo 'Cidade: ' .$row_eventos['cidade'] ?></br></td>
                <td><?php echo 'Indicação: ' .$row_eventos['medico'] ?></br></td>
                <td><?php echo 'Data/Hora: ' .$row_eventos['data_consulta'] ?></br></td>
                <td>
                    <button type="button" class="btn btn_primary"> Teste </button>
                    <button type="button" class="btn btn_warning"> Teste </button>
                    <button type="button" class="btn btn_danger"> Teste </button>
                </td>
            </tr>

        <?php } ?>
        

    </body>
</html>




