<?php

$servidor = 'localhost';
$nome = 'root';
$senha = '';
$db = 'eventos';

$connect = mysqli_connect($servidor, $nome, $senha, $db);


?>