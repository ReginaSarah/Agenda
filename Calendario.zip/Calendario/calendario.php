<?php

    //CONTAGEM DE DIAS EM CADA MES
    function diasMeses(){
        $retorno = array();

        for($i = 1; $i <= 12; $i++){
            $retorno[$i] = cal_days_in_month(CAL_GREGORIAN, $i, date('Y'));
        }
        return $retorno;
    }

    function marcarConsulta(){
        
    }

    //FORMAÇÃO DO CALENDARIO
    function Calendario(){
        $daysWeek = array(
            'Sun',
            'Mon',
            'Tue',
            'Wed',
            'Thu',
            'Fri',
            'Sat'
        );

        $diasSemana = array(
            'Domingo',
            'Segunda',
            'Terça',
            'Quarta',
            'Quinta',
            'Sexta',
            'Sabado'
        );

        $arrayMes = array(
            1 => 'Janeiro',
            2 => 'Fevereiro',
            3 => 'Março',
            4 => 'Abril',
            5 => 'Maio',
            6 => 'Junho',
            7 => 'Julho',
            8 => 'Agosto',
            9 => 'Setembro',
            10 => 'Outubro',
            11 => 'Novembro',
            12 => 'Dezembro'
        );
        $diasMeses = diasMeses();
        $arrayRetorno = array();

        for($i = 1; $i <= 12; $i++){
            $arrayRetorno[$i] = array();
            for($j = 1; $j <= $diasMeses[$i]; $j++){
                $dayMonth = gregoriantojd($i, $j, date('Y'));
                $weekMonth = jddayofweek($dayMonth, 2);
                if($weekMonth == 'Mun') 
                    $weekMonth = 'Mon';
                $arrayRetorno[$i][$j] = $weekMonth;
            }
        }
        
        echo '<a href="#" id="anterior">&laquo; </a><a href = "#" id="proximo">&raquo</a>';
        echo'<table border="0" width="100%">';
        foreach($arrayMes as $num => $mes){
            echo '<tbody id="mes_'.$num.'" class="mes">';
            echo'<tr class="mes_title"><td colspan="7">'.$mes.'</td></tr><tr>';
            foreach($diasSemana as $i => $day){
                echo '<td>'.$day.'</td>';
            }
            echo '</tr><tr>';
            $y = 0;
            foreach($arrayRetorno[$num] as $numero =>$dia){
                $y++;
                if($numero == 1){
                    $qtd = array_search($dia, $daysWeek);
                    for($i=1; $i<=$qtd; $i++){
                        echo '<td></td>';
                        $y+=1;
                    }
                }
                echo '<td>'.$numero.'</td>';
                if($y == 7){
                    $y=0;
                    echo '</tr><tr>';
                }
            }
            echo '</tr></tbody>';
        }
        echo '</table>';
        //print_r($arrayRetorno);
    }
    


?>
